import torch
import matplotlib.pyplot as plt
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import dgl
import numpy as np
import argparse
from sklearn.manifold import TSNE
import time
from dataset import Dataset
from sklearn.metrics import f1_score, accuracy_score, recall_score, roc_auc_score, precision_score, confusion_matrix
from bwgnn_model import BWGNN   # BWGNN expects only features (it stores graph in self.g)
from bwgnn_model import GCN                    # GCN expects a DGLGraph as input (uses graph.ndata)
from sklearn.model_selection import train_test_split

# Threshold adjustment function for best macro F1
def get_best_f1(labels, probs):
    best_f1, best_thre = 0, 0
    for thres in np.linspace(0.05, 0.95, 19):
        preds = np.zeros_like(labels)
        preds[probs[:, 1] > thres] = 1
        mf1 = f1_score(labels, preds, average='macro')
        if mf1 > best_f1:
            best_f1 = mf1
            best_thre = thres
    return best_f1, best_thre


def train(model, g, args):
    # Extract features and labels from the graph
    features = g.ndata['feature']
    labels = g.ndata['label']

    # Define indices. For the amazon dataset, restrict indices per the original paper.
    index = list(range(len(labels)))
    if args.dataset == 'amazon':
        index = list(range(3305, len(labels)))

    # Split indices into three sets: train (40%), then split the remaining 60% equally into validation (30%) and test (30%)
    idx_train, idx_temp, y_train, y_temp = train_test_split(
        index, labels[index], stratify=labels[index],
        train_size=0.4, random_state=42, shuffle=True
    )
    idx_val, idx_test, y_val, y_test = train_test_split(
        idx_temp, y_temp, stratify=y_temp,
        test_size=0.5, random_state=42, shuffle=True
    )

    # Create boolean masks
    train_mask = torch.zeros(len(labels), dtype=torch.bool)
    val_mask   = torch.zeros(len(labels), dtype=torch.bool)
    test_mask  = torch.zeros(len(labels), dtype=torch.bool)
    train_mask[idx_train] = True
    val_mask[idx_val] = True
    test_mask[idx_test] = True

    print('train/val/test samples: ',
          train_mask.sum().item(),
          val_mask.sum().item(),
          test_mask.sum().item())

    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)
    best_val_f1 = 0.
    final_trec, final_tpre, final_tmf1, final_tauc = 0., 0., 0., 0.

    # Calculate class weight for cross entropy (ensure weight tensor is on the right device)
    weight = (1 - labels[train_mask]).sum().item() / labels[train_mask].sum().item()
    weight_tensor = torch.tensor([1., weight]).to(labels.device)
    print('cross entropy weight: ', weight)

    time_start = time.time()
    for e in range(args.epoch):
        model.train()
        # Depending on the model type, choose the correct input:
        if hasattr(model, 'g'):
            # Model stores the graph (BWGNN), so forward takes only features.
            logits = model(features)
        else:
            # Otherwise, GCN expects the whole graph.
            logits = model(g)
        loss = F.cross_entropy(logits[train_mask], labels[train_mask], weight=weight_tensor)
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if e % 10 == 0:
            model.eval()
            with torch.no_grad():
                if hasattr(model, 'g'):
                    logits = model(features)
                else:
                    logits = model(g)
                probs = logits.softmax(dim=1)
                # Use validation set to select the best threshold and evaluate performance.
                val_f1, best_thres = get_best_f1(labels[val_mask].cpu().numpy(),
                                                 probs[val_mask].cpu().numpy())
                preds = np.zeros(len(labels))
                preds[probs[:, 1].cpu().numpy() > best_thres] = 1

                # Evaluate on test set with the threshold chosen on validation.
                trec = recall_score(labels[test_mask].cpu().numpy(), preds[test_mask])
                tpre = precision_score(labels[test_mask].cpu().numpy(), preds[test_mask])
                tmf1 = f1_score(labels[test_mask].cpu().numpy(), preds[test_mask], average='macro')
                tauc = roc_auc_score(labels[test_mask].cpu().numpy(),
                                     probs[test_mask][:, 1].cpu().numpy())

                if val_f1 > best_val_f1:
                    best_val_f1 = val_f1
                    final_trec, final_tpre, final_tmf1, final_tauc = trec, tpre, tmf1, tauc

                acc = accuracy_score(labels[val_mask].cpu().numpy(),
                                     logits[val_mask].argmax(dim=1).cpu().numpy())
                print(f"Epoch {e:03d} | Loss: {loss.item():.4f} | Val Acc: {acc:.4f} | Val F1: {val_f1:.4f} (best {best_val_f1:.4f})")
                with torch.no_grad():
                    val_preds = logits[val_mask].argmax(dim=1)
                    unique_pred, count_pred = torch.unique(val_preds, return_counts=True)
                    pred_distribution = dict(zip(unique_pred.cpu().tolist(), count_pred.cpu().tolist()))
                    print("Validation predictions distribution:", pred_distribution)

    time_end = time.time()
    print('Time cost: ', time_end - time_start, 's')
    print('Final Test Evaluation: REC {:.2f} PRE {:.2f} MF1 {:.2f} AUC {:.2f}'.format(
          final_trec * 100, final_tpre * 100, final_tmf1 * 100, final_tauc * 100))
    return final_tmf1, final_tauc


def visualize_embeddings(gcn_model, bwgnn_model, graph):
    with torch.no_grad():
        # For GCN, use the output (logits) as embeddings.
        emb_gcn = gcn_model(graph)
        # For BWGNN, pass the node features from the DGL graph.
        emb_bwgnn = bwgnn_model(graph.ndata['feature'])

    # Randomly select nodes for visualization (or use all if less than sample_size)
    num_nodes = emb_gcn.size(0)
    sample_size = 10000 if num_nodes > 10000 else num_nodes
    indices = np.random.choice(num_nodes, sample_size, replace=False)
    emb_gcn_sample = emb_gcn.cpu().numpy()[indices]
    emb_bwgnn_sample = emb_bwgnn.cpu().numpy()[indices]
    labels_sample = graph.ndata['label'].cpu().numpy()[indices]  # Changed this line

    # Reduce dimensions using t-SNE.
    tsne = TSNE(n_components=2, random_state=42)
    emb_gcn_2d = tsne.fit_transform(emb_gcn_sample)
    emb_bwgnn_2d = tsne.fit_transform(emb_bwgnn_sample)

    plt.figure(figsize=(12, 5))

    # GCN Embeddings
    plt.subplot(1, 2, 1)
    plt.scatter(emb_gcn_2d[:, 0], emb_gcn_2d[:, 1], c=labels_sample, cmap='coolwarm', s=10)
    plt.title("GCN Embeddings (Node Classification)")
    plt.colorbar()

    # BWGNN Embeddings
    plt.subplot(1, 2, 2)
    plt.scatter(emb_bwgnn_2d[:, 0], emb_bwgnn_2d[:, 1], c=labels_sample, cmap='coolwarm', s=10)
    plt.title("BWGNN Embeddings")
    plt.colorbar()

    plt.show()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='BWGNN & GCN Training')
    parser.add_argument("--dataset", type=str, default="tfinance",
                        help="Dataset for this model (yelp/amazon/tfinance/tsocial)")
    parser.add_argument("--epoch", type=int, default=200, help="The max number of epochs")
    parser.add_argument("--run", type=int, default=1, help="Running times")
    parser.add_argument("--hid_dim", type=int, default=64, help="Hidden layer dimension")
    parser.add_argument("--order", type=int, default=2, help="Order C in Beta Wavelet")
    parser.add_argument("--homo", type=int, default=1, help="1 for BWGNN(Homo) and 0 for BWGNN(Hetero)")
    args = parser.parse_args()
    print(args)

    dataset_name = args.dataset
    homo = args.homo
    order = args.order
    h_feats = args.hid_dim
    graph = Dataset(dataset_name, homo).graph
    in_feats = graph.ndata['feature'].shape[1]
    num_classes = 2

    # Print overall, train, and test label distributions if available.
    unique, counts = torch.unique(graph.ndata["label"], return_counts=True)
    label_distribution = dict(zip(unique.cpu().tolist(), counts.cpu().tolist()))
    print("Overall label distribution:", label_distribution)
    if "train_mask" in graph.ndata and "test_mask" in graph.ndata:
        train_mask_existing = graph.ndata["train_mask"].bool()
        test_mask_existing = graph.ndata["test_mask"].bool()
        unique_train, counts_train = torch.unique(graph.ndata["label"][train_mask_existing], return_counts=True)
        train_distribution = dict(zip(unique_train.cpu().tolist(), counts_train.cpu().tolist()))
        print("Existing training set label distribution:", train_distribution)
        unique_test, counts_test = torch.unique(graph.ndata["label"][test_mask_existing], return_counts=True)
        test_distribution = dict(zip(unique_test.cpu().tolist(), counts_test.cpu().tolist()))
        print("Existing testing set label distribution:", test_distribution)

    #########################################
    # Run BWGNN for Node Classification
    #########################################
    print("\n===== Running BWGNN =====")
    # BWGNN expects the graph in its constructor and takes only features in forward.
    bwgnn_model = BWGNN(in_feats, 32, num_classes, graph=graph, d=order)
    trained_bwg = train(bwgnn_model, graph, args)

    #########################################
    # Run GCN for Node Classification
    #########################################
    print("\n===== Running GCN =====")
    # This GCN version expects the entire graph as input.
    gcn_model = GCN(in_feats, 32, num_classes)
    trained_gcn = train(gcn_model, graph, args)

    visualize_embeddings(gcn_model, bwgnn_model, graph)