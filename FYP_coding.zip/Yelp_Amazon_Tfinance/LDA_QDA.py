import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import time
from dataset import Dataset
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis, QuadraticDiscriminantAnalysis
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, roc_auc_score, confusion_matrix
from sklearn.ensemble import AdaBoostClassifier
from lightgbm import LGBMClassifier
import warnings

warnings.filterwarnings("ignore")


def run_analysis(dataset_name):
    # Load the dataset (either 'yelp' or 'amazon')
    ds = Dataset(name=dataset_name)
    graph = ds.graph

    X = graph.ndata["feature"].numpy()
    y = graph.ndata["label"].numpy()

    # Change test ratio here
    X_train, X_temp, y_train, y_temp = train_test_split(X, y, train_size=0.4, random_state=42)
    X_test, X_val, y_test, y_val = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42)

    print(f"\nDataset: {dataset_name}")
    print("Train set size:", X_train.shape[0])
    print("Validation set size:", X_val.shape[0])
    print("Test set size:", X_test.shape[0])
    train_size=0.01
    best_shrinkage = None
    best_val_accuracy = 0.0
    shrinkage_values = [None, 0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0]
    print("\nTuning LDA:")
    for shrink in shrinkage_values:
        lda = LinearDiscriminantAnalysis(solver='lsqr', shrinkage=shrink)
        lda.fit(X_train, y_train)
        y_val_pred = lda.predict(X_val)
        acc = accuracy_score(y_val, y_val_pred)
        print(f"  LDA with shrinkage={shrink} --> Validation Accuracy: {acc:.4f}")
        if acc > best_val_accuracy:
            best_val_accuracy = acc
            best_shrinkage = shrink
    print(f"Best LDA shrinkage parameter: {best_shrinkage} with validation accuracy: {best_val_accuracy:.4f}")

    best_reg_param = None
    best_val_accuracy_qda = 0.0
    reg_params = [0.0, 0.01, 0.1, 0.5, 1.0]
    print("\nTuning QDA:")
    for reg in reg_params:
        qda = QuadraticDiscriminantAnalysis(reg_param=reg)
        try:
            qda.fit(X_train, y_train)
            y_val_pred_qda = qda.predict(X_val)
            acc_qda = accuracy_score(y_val, y_val_pred_qda)
            print(f"  QDA with reg_param={reg} --> Validation Accuracy: {acc_qda:.4f}")
            if acc_qda > best_val_accuracy_qda:
                best_val_accuracy_qda = acc_qda
                best_reg_param = reg
        except Exception as e:
            print(f"  QDA with reg_param={reg} failed: {e}")
    print(f"Best QDA reg_param: {best_reg_param} with validation accuracy: {best_val_accuracy_qda:.4f}")

    X_train_val = np.concatenate((X_train, X_val), axis=0)
    y_train_val = np.concatenate((y_train, y_val), axis=0)

    lda_final = LinearDiscriminantAnalysis(solver='lsqr', shrinkage=best_shrinkage)
    lda_final.fit(X_train_val, y_train_val)
    y_test_pred_lda = lda_final.predict(X_test)
    print(f"\n{dataset_name} Final LDA ({train_size}) Test Results:")
    print("  Test Accuracy: {:.4f}".format(accuracy_score(y_test, y_test_pred_lda)))
    print("  Classification Report:\n", classification_report(y_test, y_test_pred_lda))
    plt.figure(figsize=(6, 6))
    sns.heatmap(confusion_matrix(y_test, y_test_pred_lda), annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title("LDA Test Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()

    qda_final = QuadraticDiscriminantAnalysis(reg_param=best_reg_param)
    qda_final.fit(X_train_val, y_train_val)
    y_test_pred_qda = qda_final.predict(X_test)
    print(f"\n{dataset_name} Final QDA ({train_size}) Test Results:")
    print("  Test Accuracy: {:.4f}".format(accuracy_score(y_test, y_test_pred_qda)))
    print("  Classification Report:\n", classification_report(y_test, y_test_pred_qda))
    print("-" * 50)
    plt.figure(figsize=(6, 6))
    sns.heatmap(confusion_matrix(y_test, y_test_pred_qda), annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title("QDA Test Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()

    time_start = time.time()
    ada = AdaBoostClassifier(n_estimators=50, random_state=42)
    ada.fit(X_train, y_train)
    y_test_pred_ada = ada.predict(X_test)
    time_end = time.time()
    duration = time_end - time_start
    y_test_prob_ada = ada.predict_proba(X_test)[:, 1]
    print(f"\n{dataset_name} Final AdaBoost ({train_size}) Test Results:")
    print("Classification Report:")
    print(classification_report(y_test, y_test_pred_ada))
    y_test_prob_ada = ada.predict_proba(X_test)[:, 1]
    ada_roc_auc_test = roc_auc_score(y_test, y_test_prob_ada)
    print("AdaBoost Confusion Matrix:\n", confusion_matrix(y_test, y_test_pred_ada))
    print("AdaBoost Test ROC AUC Score:", ada_roc_auc_test)
    print("\n----------------------\n")

    time_start = time.time()
    lgbm = LGBMClassifier(n_estimators=50, random_state=42)
    lgbm.fit(X_train, y_train)
    y_test_pred_lgbm = lgbm.predict(X_test)
    time_end = time.time()
    duration = time_end - time_start
    y_test_prob_ada = lgbm.predict_proba(X_test)[:, 1]
    print(f"\n{dataset_name} Final LightGBM ({train_size}) Test Results:")
    print("Classification Report:")
    print(classification_report(y_test, y_test_pred_lgbm))
    y_test_prob_lgbm = lgbm.predict_proba(X_test)[:, 1]
    lgbm_roc_auc_test = roc_auc_score(y_test, y_test_prob_lgbm)
    print("LGBM Confusion Matrix:\n", confusion_matrix(y_test, y_test_pred_lgbm))
    print("LGBM Test ROC AUC Score:", lgbm_roc_auc_test)
    print("\n----------------------\n")


if __name__ == "__main__":
    for dataset_name in ["yelp", "amazon", "tfinance"]:
        run_analysis(dataset_name)
