from dataset import Dataset
import numpy as np
import time
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import AdaBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.metrics import (
    accuracy_score, confusion_matrix, recall_score, precision_score, f1_score,
    classification_report,roc_auc_score
)


def main(dataset_name):
    ds = Dataset(name = dataset_name)
    g = ds.graph

    features = g.ndata['feature'].numpy()
    labels = g.ndata['label'].numpy()

    X_train, X_temp, y_train, y_temp = train_test_split(
        features, labels, train_size=0.4, stratify=labels, random_state=42
    )

    # Change the ratio here
    X_test, X_val, y_test, y_val = train_test_split(
        X_temp, y_temp, test_size=0.5, stratify=y_temp, random_state=42
    )

    unique_train, counts_train = np.unique(y_train, return_counts=True)
    unique_val, counts_val = np.unique(y_val, return_counts=True)
    unique_test, counts_test = np.unique(y_test, return_counts=True)
    print("Training set label distribution:", dict(zip(unique_train, counts_train)))
    print("Validation set label distribution:", dict(zip(unique_val, counts_val)))
    print("Test set label distribution:", dict(zip(unique_test, counts_test)))
    print("\n----------------------\n")

    # AdaBoost
    time_start = time.time()
    ada = AdaBoostClassifier(n_estimators=50, random_state=42)
    ada.fit(X_train, y_train)
    time_end = time.time()
    duration = time_end - time_start

    y_val_pred_ada = ada.predict(X_val)
    ada_accuracy_val = accuracy_score(y_val, y_val_pred_ada)
    ada_cm_val = confusion_matrix(y_val, y_val_pred_ada)
    ada_recall_val = recall_score(y_val, y_val_pred_ada, zero_division=0)
    ada_precision_val = precision_score(y_val, y_val_pred_ada, zero_division=0)
    ada_f1_val = f1_score(y_val, y_val_pred_ada, zero_division=0)

    print(duration)
    print("AdaBoost Validation Metrics:")
    print("Accuracy:", ada_accuracy_val)
    print("Confusion Matrix:\n", ada_cm_val)
    print("Recall:", ada_recall_val)
    print("Precision:", ada_precision_val)
    print("F1-Score:", ada_f1_val)
    print("\n----------------------\n")

    # LightGBM
    time_start = time.time()
    lgbm = LGBMClassifier(n_estimators=50, random_state=42)
    lgbm.fit(X_train, y_train)
    time_end = time.time()
    duration = time_end - time_start
    y_val_pred_lgbm = lgbm.predict(X_val)
    lgbm_accuracy_val = accuracy_score(y_val, y_val_pred_lgbm)
    lgbm_cm_val = confusion_matrix(y_val, y_val_pred_lgbm)
    lgbm_recall_val = recall_score(y_val, y_val_pred_lgbm, zero_division=0)
    lgbm_precision_val = precision_score(y_val, y_val_pred_lgbm, zero_division=0)
    lgbm_f1_val = f1_score(y_val, y_val_pred_lgbm, zero_division=0)

    print(duration)
    print("LightGBM Validation Metrics:")
    print("Accuracy:", lgbm_accuracy_val)
    print("Confusion Matrix:\n", lgbm_cm_val)
    print("Recall:", lgbm_recall_val)
    print("Precision:", lgbm_precision_val)
    print("F1-Score:", lgbm_f1_val)
    print("\n----------------------\n")


    y_test_pred_ada = ada.predict(X_test)
    ada_accuracy_test = accuracy_score(y_test, y_test_pred_ada)
    ada_cm_test = confusion_matrix(y_test, y_test_pred_ada)
    ada_recall_test = recall_score(y_test, y_test_pred_ada, zero_division=0)
    ada_precision_test = precision_score(y_test, y_test_pred_ada, zero_division=0)
    ada_f1_test = f1_score(y_test, y_test_pred_ada, zero_division=0)

    print("AdaBoost Test Metrics:")
    print("Classification Report:")
    print(classification_report(y_test, y_test_pred_ada))
    y_test_prob_ada = ada.predict_proba(X_test)[:, 1]  # Probabilities for class 1
    ada_roc_auc_test = roc_auc_score(y_test, y_test_prob_ada)
    print("AdaBoost Confusion Matrix:\n", confusion_matrix(y_test, y_test_pred_ada))
    print("AdaBoost Test ROC AUC Score:", ada_roc_auc_test)
    print("\n----------------------\n")
    print("\n")
    plt.figure(figsize=(6, 6))
    sns.heatmap(confusion_matrix(y_test, y_test_pred_ada), annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title("AdaBoost Test Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()

    y_test_pred_lgbm = lgbm.predict(X_test)
    lgbm_accuracy_test = accuracy_score(y_test, y_test_pred_lgbm)
    lgbm_cm_test = confusion_matrix(y_test, y_test_pred_lgbm)
    lgbm_recall_test = recall_score(y_test, y_test_pred_lgbm, zero_division=0)
    lgbm_precision_test = precision_score(y_test, y_test_pred_lgbm, zero_division=0)
    lgbm_f1_test = f1_score(y_test, y_test_pred_lgbm, zero_division=0)

    print("LightGBM Test Metrics:")
    print("Classification Report:")
    print(classification_report(y_test, y_test_pred_lgbm))
    y_test_prob_lgbm = ada.predict_proba(X_test)[:, 1]  # Probabilities for class 1
    lgbm_roc_auc_test = roc_auc_score(y_test, y_test_prob_lgbm)
    print("LightGBM Confusion Matrix:\n", confusion_matrix(y_test, y_test_pred_lgbm))
    print("LightGBM Test ROC AUC Score:", lgbm_roc_auc_test)
    print("\n----------------------\n")
    print("\n")
    plt.figure(figsize=(6, 6))
    sns.heatmap(confusion_matrix(y_test, y_test_pred_lgbm), annot=True, fmt="d", cmap="Blues", cbar=False)
    plt.title("LightGBM Test Confusion Matrix")
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.show()


if __name__ == "__main__":
    for dataset_name in ["yelp", "amazon", "tfinance"]:
        main(dataset_name)
